<?php

namespace Pterodactyl\Exceptions\Repository;

use Pterodactyl\Exceptions\PterodactylException;

class RepositoryException extends PterodactylException
{
}
