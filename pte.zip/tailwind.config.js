const colors = require('tailwindcss/colors');

const gray = {
    50: 'hsl(216, 33%, 97%)',
    100: 'hsl(214, 15%, 91%)',
    200: 'hsl(210, 16%, 82%)',
    300: 'hsl(211, 13%, 65%)',
    400: 'hsl(211, 10%, 53%)',
    500: 'hsl(211, 12%, 43%)',
    600: 'hsl(209, 14%, 37%)',
    700: 'hsl(209, 18%, 30%)',
    800: 'hsl(209, 20%, 25%)',
    900: 'hsl(210, 24%, 16%)',
};

// New purple color palette based on #7200ff
const purple = {
    50: 'hsl(265, 100%, 97%)',
    100: 'hsl(265, 100%, 91%)',
    200: 'hsl(265, 100%, 82%)',
    300: 'hsl(265, 100%, 75%)',
    400: 'hsl(265, 100%, 65%)',
    500: 'hsl(265, 100%, 50%)', // #7200ff
    600: 'hsl(265, 100%, 45%)',
    700: 'hsl(265, 100%, 40%)',
    800: 'hsl(265, 100%, 35%)',
    900: 'hsl(265, 100%, 25%)',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
                sans: ['"Inter"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#131a20',
                // New primary color with purple
                primary: purple,
                // Keep existing colors for backward compatibility
                gray: gray,
                neutral: gray,
                cyan: colors.cyan,
                // New purple color palette
                purple: purple,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
            backgroundColor: {
                'primary': purple[500],
                'primary-hover': purple[600],
                'primary-dark': purple[700],
            },
            textColor: {
                'primary': purple[500],
                'primary-hover': purple[600],
            },
            ringColor: {
                'primary': purple[500],
            },
            boxShadow: {
                'primary': '0 0 0 3px rgba(114, 0, 255, 0.1)',
            },
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ],
    // Safelist to ensure purple classes are always generated
    safelist: [
        {
            pattern: /(bg|text|border|ring)-purple-(50|100|200|300|400|500|600|700|800|900)/,
        },
        {
            pattern: /(bg|text|border|ring)-primary-(50|100|200|300|400|500|600|700|800|900)/,
        },
    ]
};